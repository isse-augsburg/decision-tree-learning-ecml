# decision-tree-learning

Simply download the whole package and run the index.html file.
This project won't work properly with Microsoft Edge. 
Please use Firefox or Chrome.

Due to a new security policy update (cors), by default, it is no longer an option to
load local files under the same directory into the browser. However, to use this software,
it is necessary to access the .js files.

This new feature could be disabled:

Firefox: enter "about:config" and then change the value of "privacy.file_unique_origin" to false
Chrome: https://www.chromium.org/developers/how-tos/run-chromium-with-flags  
        https://stackoverflow.com/questions/3102819/disable-same-origin-policy-in-chrome

